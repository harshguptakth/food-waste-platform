const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const DonorSchema = new Schema({
  name: String,
  email: String,
  phone: String,
  address: String,
  location: { type: { type: String, default: 'Point' }, coordinates: [Number] } // [lng, lat]
});
DonorSchema.index({ location: '2dsphere' });
module.exports = mongoose.model('Donor', DonorSchema);
