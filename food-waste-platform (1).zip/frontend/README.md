Frontend: React app.
- cd frontend
- npm install
- npm start
