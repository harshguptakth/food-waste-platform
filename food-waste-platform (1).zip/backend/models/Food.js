const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const FoodSchema = new Schema({
  donor: { type: Schema.Types.ObjectId, ref: 'Donor' },
  title: String,
  quantity: String,
  description: String,
  pickupTime: Date,
  location: { type: { type: String, default: 'Point' }, coordinates: [Number] }, // [lng, lat]
  picked: { type: Boolean, default: false }
});
FoodSchema.index({ location: '2dsphere' });
module.exports = mongoose.model('Food', FoodSchema);
