const express = require('express');
const router = express.Router();
const NGO = require('../models/NGO');
// Register NGO
router.post('/', async (req,res) => {
  try{
    const n = new NGO(req.body);
    await n.save();
    res.json(n);
  }catch(e){ res.status(500).json({error:e.message});}
});
// NGO: search nearby food (lat & lng and radius in meters)
const Food = require('../models/Food');
router.get('/search-food', async (req,res)=>{
  try{
    const { lat, lng, radius=5000 } = req.query;
    if(!lat || !lng) return res.status(400).json({error:'provide lat & lng'});
    const foods = await Food.find({
      picked: false,
      location: {
        $near: {
          $geometry: { type: "Point", coordinates: [ parseFloat(lng), parseFloat(lat) ] },
          $maxDistance: parseInt(radius)
        }
      }
    }).populate('donor');
    res.json(foods);
  }catch(e){ res.status(500).json({error:e.message});}
});
module.exports = router;
