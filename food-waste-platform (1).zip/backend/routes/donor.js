const express = require('express');
const router = express.Router();
const Donor = require('../models/Donor');
// Create donor
router.post('/', async (req,res) => {
  try{
    const d = new Donor(req.body);
    await d.save();
    res.json(d);
  }catch(e){ res.status(500).json({error:e.message});}
});
// List donors
router.get('/', async (req,res)=>{
  const donors = await Donor.find();
  res.json(donors);
});
module.exports = router;
