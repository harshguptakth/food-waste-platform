const mongoose = require('mongoose');
const Schema = mongoose.Schema;
const NGOSchema = new Schema({
  name: String,
  email: String,
  phone: String,
  address: String,
  location: { type: { type: String, default: 'Point' }, coordinates: [Number] } // [lng, lat]
});
NGOSchema.index({ location: '2dsphere' });
module.exports = mongoose.model('NGO', NGOSchema);
