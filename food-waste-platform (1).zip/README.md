# Food Waste Donation Platform (MERN) - Local Setup

## Overview
This is a minimal MERN-stack demo implementing:
- Donor registration (storing location coordinates)
- NGO registration
- Add food items
- NGO search for nearby food using MongoDB geospatial queries
- Placeholder for Email (nodemailer) and SMS (Twilio) integration
- Frontend React demo to create donors and add food

## What's included
- backend/ (Express + Mongoose)
- frontend/ (React demo)
- .env.example in backend — fill with credentials

## Prerequisites
- Node.js (v18+ recommended)
- npm
- MongoDB (local) OR MongoDB Atlas (update MONGO_URI in backend/.env.example)

## Steps (Local)
1. Extract the zip.
2. Backend:
   - Open terminal, `cd backend`
   - Copy `.env.example` to `.env` and update values (MONGO_URI, EMAIL_*, JWT_SECRET)
   - `npm install`
   - `npm run dev` (requires nodemon) or `npm start`
3. Frontend:
   - In new terminal, `cd frontend`
   - `npm install`
   - `npm start` (opens at http://localhost:3000)
4. Try endpoints:
   - Create donor: POST http://localhost:5000/api/donors  (body: name,email,phone,address,location)
   - Create food: POST http://localhost:5000/api/foods (body: donor, title, quantity, description, pickupTime, location)
   - NGO search: GET http://localhost:5000/api/ngos/search-food?lat=12.34&lng=56.78&radius=5000

## Notes & Next steps
- **Geocoding / Google Maps:** Frontend should call Google Geocoding API (use GOOGLE_MAPS_API_KEY) to convert address -> lat/lng and set `location.coordinates = [lng, lat]`.
- **Email notifications:** backend/services/email.js has sample nodemailer setup (you can add).
- **SMS (Twilio):** add Twilio integration to notify NGOs on a match (example commented).
- **Authentication & Admin:** You can extend with JWT auth; models already prepared for extension.
- **Production:** Use HTTPS, secure env vars, and a hosted MongoDB.

## Files
- backend/server.js
- backend/routes/*
- backend/models/*
- frontend/src/*

--- End
