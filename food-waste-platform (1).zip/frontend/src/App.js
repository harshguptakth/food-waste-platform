import React, {useState} from 'react';
import axios from 'axios';
function App(){
  const [donor, setDonor] = useState({name:'',email:'',phone:'',address:'', location:{coordinates:[0,0]}});
  const [food, setFood] = useState({title:'',quantity:'',description:'',pickupTime:'', location:{coordinates:[0,0]}});
  const api = 'http://localhost:5000/api';
  const createDonor = async ()=> {
    try{
      // If you have address -> call Google Geocode to get lat/lng and set location coordinates [lng,lat]
      const res = await axios.post(api+'/donors', {...donor});
      alert('Donor created: '+res.data._id);
    }catch(e){ alert(e.response?.data?.error || e.message);}
  };
  const addFood = async ()=>{
    try{
      const res = await axios.post(api+'/foods', {...food});
      alert('Food added: '+res.data._id);
    }catch(e){ alert(e.response?.data?.error || e.message);}
  };
  return (<div style={{padding:20,fontFamily:'Arial'}}>
    <h2>Food Waste Donation - Demo</h2>
    <section style={{marginBottom:20}}>
      <h3>Create Donor</h3>
      <input placeholder="Name" value={donor.name} onChange={e=>setDonor({...donor,name:e.target.value})} /><br/>
      <input placeholder="Email" value={donor.email} onChange={e=>setDonor({...donor,email:e.target.value})} /><br/>
      <input placeholder="Phone" value={donor.phone} onChange={e=>setDonor({...donor,phone:e.target.value})} /><br/>
      <textarea placeholder="Address" value={donor.address} onChange={e=>setDonor({...donor,address:e.target.value})} /><br/>
      <button onClick={createDonor}>Create Donor</button>
    </section>
    <section>
      <h3>Add Food</h3>
      <input placeholder="Title" value={food.title} onChange={e=>setFood({...food,title:e.target.value})} /><br/>
      <input placeholder="Quantity" value={food.quantity} onChange={e=>setFood({...food,quantity:e.target.value})} /><br/>
      <input placeholder="Pickup Time (ISO)" value={food.pickupTime} onChange={e=>setFood({...food,pickupTime:e.target.value})} /><br/>
      <textarea placeholder="Description" value={food.description} onChange={e=>setFood({...food,description:e.target.value})} /><br/>
      <button onClick={addFood}>Add Food</button>
    </section>
    <p style={{marginTop:20,fontSize:12,color:'#666'}}>This is a minimal demo frontend. For full features (maps, geocoding, auth) follow README.</p>
  </div>);
}
export default App;
