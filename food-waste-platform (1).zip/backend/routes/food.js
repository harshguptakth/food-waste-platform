const express = require('express');
const router = express.Router();
const Food = require('../models/Food');
// Add food item
router.post('/', async (req,res)=>{
  try{
    const f = new Food(req.body);
    await f.save();
    res.json(f);
  }catch(e){ res.status(500).json({error:e.message});}
});
// Mark picked
router.post('/:id/pick', async (req,res)=>{
  try{
    const f = await Food.findById(req.params.id);
    if(!f) return res.status(404).json({error:'not found'});
    f.picked = true;
    await f.save();
    res.json({ok:true});
  }catch(e){ res.status(500).json({error:e.message});}
});
module.exports = router;
